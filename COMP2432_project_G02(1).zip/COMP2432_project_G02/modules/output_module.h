//
// Created by 袁蕴宸 on 25/2/2023.
//

#ifndef COMP2432_PROJECT_G02_OUTPUT_MODULE_H
#define COMP2432_PROJECT_G02_OUTPUT_MODULE_H

#include "../classes/scheduling.h"


void outputModule (int** scheduleMatrix, int userNum, int apNum, enum SCHEDULING_ALGORITHM algorithm);

#endif //COMP2432_PROJECT_G02_OUTPUT_MODULE_H
