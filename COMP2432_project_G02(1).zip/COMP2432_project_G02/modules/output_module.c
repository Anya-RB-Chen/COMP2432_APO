//
// Created by 袁蕴宸 on 25/2/2023.
//

#include "output_module.h"


#include "../classes/scheduling.h"
#include "../main.h"


//output module:

//input:
//1, array of  appointment information: g_apNum, g_appointmentArray
//2, schedule matrix: scheduleMatrix -- row: userNum, col: apNum.
//3' algorthm name: algorithm
//output:
//standard format from project requirement
//1,appointment schedule: personal schedule (time type people) for all users
//2,reject list:
//3, performance analysis
// stdout / txt file ?
void outputModule (int** scheduleMatrix, int userNum, int apNum, enum SCHEDULING_ALGORITHM algorithm) {

}