
//system header file
#include <stdio.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//program header file
#include "classes/time_type.h"
#include "modules/modules.h"
#include "classes/appointment.h"
#include "main.h"



//global variable definition
//（1）time
struct STime g_startTime, g_endTime; //define valid time range

//(2) name
char** g_nameMap; //array to store the user name.
int g_userNum;
//related function

//(3) IPC
int* g_p2c_fd; //pointer of pipe from parent to child
int* g_c2p_fd; //pointer of pipe from child to parent;

//(4) appointment
int g_apNum = 0;
struct SAppointment g_appointmentArray[DEFAULT_CAPACITY_OF_VECTOR]; //assumption: not exceed the capacity
//!security problem: visible to the user process

//static function/ variable declaration.
static void initialize(int argc, char* argv[]);
static int getInstructionMode (char* instruction);
static void freeUpProgram ();

//--------------------------------------implement---------------------------------------------------------------------

//function implement.

//level 0:
int main(int argc, char* argv[]) {

   //(1) initialize
   initialize(argc, argv);

   //(2) interpreter
   char instruction[100];
    printf("Please enter appointment:\n");
    scanf("%s", instruction);
    int instructionMode = getInstructionMode(instruction);
    while (instructionMode != 0) {
        if (instructionMode == 1) {
            appointmentModule(instruction);
        } else {
            scheduleModule(instruction);
        }

        printf("Please enter appointment:\n");
        scanf("%s", instruction);
        instructionMode = getInstructionMode(instruction);
    }
    //(3) exit the program
    freeUpProgram();
    exit(0);
}

//level 1: initialize global variable | create child process.
static void initialize(int argc, char* argv[]) {
    //(1) initialize global variable.
    g_startTime ;
    g_endTime ;
    //get
    g_userNum = 0;

    g_p2c_fd = (int*) (malloc(sizeof(int) * (2 * g_userNum + 1)));
    g_p2c_fd = (int*) (malloc(sizeof(int) * (2 * g_userNum + 1)));
    //close

    g_nameMap = (char**) (malloc(sizeof(char*) * g_userNum));
    int i, size;
    for (i = 0; i < g_userNum; ++i) {
        size = strlen(argv[0]);
        g_nameMap[i] = malloc(sizeof(char*) * size);
        strcpy(g_nameMap[i], argv[0]);
    }

    //(2) create child process.
    int userIndex;
    for (userIndex = 0; userIndex < g_userNum; ++userIndex) {
        int childid;
        if ((childid = fork()) < 0) {
            perror("fork");
            exit(1);
        } else if (childid == 0) {
            userProcess (userIndex);
        }
    }
}

static int getInstructionMode (char* instruction) {

}
static void freeUpProgram () {

}