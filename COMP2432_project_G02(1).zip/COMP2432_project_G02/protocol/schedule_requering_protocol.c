//
// Created by 袁蕴宸 on 25/2/2023.
//

#include "schedule_requering_protocol.h"
#include "../classes/scheduling.h"

//special one:
void  scheduleRequering_protocol_serverAPI(char* requestMessage, int wp, struct SAppointment ap_array[], int arraySize) {
    enum SCHEDULING_ALGORITHM algorithm = scheduleRequering_protocol_requestMessage_decoding(requestMessage);


    int** personalSchedule;
    switch (algorithm) {
        case FCFS:
            personalSchedule = FCFS_schecule_algorithm (ap_array,  arraySize);
            break;
    }

    //
}