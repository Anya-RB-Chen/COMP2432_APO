////
//// Created by 袁蕴宸 on 19/2/2023.
////
//
//#ifndef COMP2432_PROJECT_G02_VECTOR_H
//#define COMP2432_PROJECT_G02_VECTOR_H
//
//#include "appointment.h"
//
//static int DEAULT_CAPACITY = 128;
//
//struct Int_vector {
//    int* data;
//    int capacity;
//    int size;
//};
//
//struct AP_vector {
//    struct  SAppointment*data;
//    int capacity;
//    int size;
//};
//
//void append(struct Int_vector ivec, struct SAppointment e);
//void add (struct AP_vector ivec, int e);
//
//static void int_expand (struct Int_vector ivec);
//static void ap_expand (struct AP_vector ivec);
//
//void sortAP_by_time (struct AP_vector );
//void sortAP_by_index (struct AP_vector);
//
//
//#endif //COMP2432_PROJECT_G02_VECTOR_H
//

//
