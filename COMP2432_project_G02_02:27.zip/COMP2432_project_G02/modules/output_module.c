//
// Created by 袁蕴宸 on 25/2/2023.
//

#include "output_module.h"


#include "../classes/scheduling.h"
#include "../main.h"


//output module:

void outputModule (int** scheduleMatrix, enum SCHEDULING_ALGORITHM algorithm) {

}